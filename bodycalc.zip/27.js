
frmPref.innerHTML=[  "<div id='lblUnits' class='graytitle' data-nsb-type=Label style='text-align:left; text-shadow:none; font-size:20px; font-family:helvetica; font-style:normal; font-weight:bold; color:black; background-color:transparent; border-style:;border-color:transparent;border-width:1px; ' >Units</div>",
  NSB.HeaderBar_jqm14('hdrPref', 'Preferences', 'Back', 'back', 'left', '', 'false', 'right', ' style="" class=" "', '', ''),
  NSB.RadioButton_jqm('radUnits', '122', 'SI, US', '1', style="", 'data-type=horizontal ', '', ' ', '', 'left'),
  ].join('');
