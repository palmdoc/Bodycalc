
frmMain.innerHTML=[  "<div id='AdSense1' style='background-color:white;' class='adsense'></div>",
  "<button id='btnHeight' class='ui-btn ui-mini  ui-btn-inline ui-icon-false ui-btn-icon-none  ' style='margin:0px; overflow:visible; font-size:17px; font-family:; font-style:; font-weight:; color:Blue; ;  ' data-nsb-type=Button_jqm>Enter Height</button>",
  NSB.Select_jqm('selHeight', 'cm, in', '1 , 2.54', 0, 1, '', '','', 'arrow-d', 'right', 'false', 'true', '', '', '', '', '','', ''),
  "<div id='txtHeight_wrapper'><input id='txtHeight' type='number' name='' autocorrect='on' autocomplete='on' autocapitalize='on' maxlength=32 step=any value='' placeholder='' data-nsb-type='TextBox_jqm'  class='ui-mini ui-btn-  ' readonly=\"readonly\"></div>",
  "<button id='btnWeight' class='ui-btn ui-mini  ui-btn-inline ui-icon-false ui-btn-icon-none  ' style='margin:0px; overflow:visible; font-size:17px; font-family:; font-style:; font-weight:; color:Blue; ;  ' data-nsb-type=Button_jqm>Enter Weight</button>",
  NSB.HeaderBar_jqm14('hdrMain', 'BodyCalc', 'Pref', 'star', 'left', 'About', 'info', 'right', ' style="" class=" "', '', ''),
  "<div id='txtWeight_wrapper'><input id='txtWeight' type='number' name='' autocorrect='on' autocomplete='on' autocapitalize='on' maxlength=32 step=any value='' placeholder='' data-nsb-type='TextBox_jqm'  class='ui-mini ui-btn-  ' readonly=\"readonly\"></div>",
  NSB.Select_jqm('selWeight', 'kg,lb', '1, 0.45359237', 0, 1, '', '','', 'arrow-d', 'right', 'false', 'true', '', '', '', '', '','', ''),
  "<button id='btnGo' class='ui-btn ui-mini  ui-btn-inline ui-icon-false ui-btn-icon-none  ' style='margin:0px; overflow:visible; font-size:20px; font-family:; font-style:; font-weight:; color:Green; ;  ' data-nsb-type=Button_jqm>Proceed</button>",
  "<button id='btnClear' class='ui-btn ui-mini  ui-btn-inline ui-icon-false ui-btn-icon-none  ' style='margin:0px; overflow:visible; font-size:20px; font-family:; font-style:; font-weight:; color:Red; ;  ' data-nsb-type=Button_jqm>Clear</button>",
  ].join('');
